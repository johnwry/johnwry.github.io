# Governing framework: It Is Settled

Author: John Wry. Updated October 7, 2026. Follow subsequent author corrections. This framework supersedes earlier directions that turn the book toward reader sentiment or confidence.

## Purpose

Follow Romans to establish what God has accomplished through Jesus Christ and what that means before God. Ask: **What has God settled through Christ, and what in Romans establishes that it remains settled?**

“It is settled” is the intended, earned conclusion. It cannot become a premise imposed upon every passage. Scripture must be permitted to qualify or overturn any proposed claim.

Keep the argument focused on God's righteousness, judgment, provision, resolve, acceptance, faithfulness, and purpose. Explain what God has done and Paul's reasons. Do not organize the book around generating assurance, relief, confidence, or a desired emotional reaction. The reader's response can follow without being managed.

## What is settled versus recognizing it

What God establishes and a person's recognition or enjoyment of it are different matters. Confidence does not cause, complete, or sustain God's work. Never write “It is settled because our confidence rests in the God who has acted for us in Christ.” Repeatedly appending “therefore our confidence can rest” also redirects the book toward the wrong subject.

John's thesis concerns the standing God establishes for the person justified through faith in Christ, not universal justification irrespective of faith. Explain faith where Paul explains it. Distinguish provision, reception, and awareness of the implications. Do not treat weak feelings, moral failure, wavering assurance, and repudiation of faith as interchangeable. Claims about subsequent unbelief require direct examination of the relevant passages, not an assumption that faith is a feeling.

## Bible edition

John selected the public-domain **World English Bible (WEB)** on October 7, 2026. Use the Classic American English edition consistently unless later directed otherwise. Verify every exact quotation. Keep paraphrase distinct from quotation. Existing NASB quotations require individual replacement and verification during manuscript revision.

## Scriptural demonstration

Scripture alone establishes or evaluates teaching. Read each unit's audience, question, sequence, reasons, qualifications, commands, and conclusion. Show the steps from text to claim. Distinguish explicit statements, interpretation, and application. A reference after an assertion is insufficient.

No commentary, sermons, theological articles, study notes, search-result opinions, or remembered theological systems. Websites may supply biblical wording and reference verification. Edition information and reuse terms may be checked administratively; they supply no theological authority.

Explain biblical terms in context. Do not replace Paul's reasoning with reference, alignment, system, position, or reality. Illustrations illuminate an argument; they cannot establish doctrine.

God's acceptance does not mean indifference to sin. Give Romans 3:21–26 substantial treatment: redemption, Christ's blood, the demonstration of God's righteousness, and justifying action. Calling Christ sufficient cannot replace explaining what he accomplished.

## Argument map

| Passage | Distinct contribution |
|---|---|
| Romans 1:1–17 | Gospel source, promised message concerning the Son, power, faith, obedience. |
| 1:18–3:20 | Revelation, rejection, judgment, accountability of the judging person, law, privilege, all under sin. |
| 3:21–31 | God's righteousness and justifying action through Christ; redemption, grace, faith, excluded boasting. |
| 4 | Abraham and David, credited righteousness, wages and gift, circumcision, promise, faith, resurrection. Reserve developed peace and reconciliation for Romans 5. |
| 5:1–11 | Peace, access, hope, suffering, demonstrated love, and the reasoning from justification and reconciliation to future salvation. |
| 5:12–21 | Adam and Christ: differences as well as parallels; explain the scope of Paul's claims. |
| 6 | Union with Christ, death and resurrection, dominion, commands to present and obey, slavery, fruit, death and eternal life. |
| 7 | Release from law, belonging to Christ, good law, sin's action, conflict, deliverance. Justify the reading of the speaker. |
| 8 | Spirit, no condemnation, life and death, adoption, bodily resurrection, suffering, hope, God's purpose, justification, intercession, love. |
| 9–11 | Israel and God's word, promise, mercy, faith, unbelief, remnant, olive tree, God's purpose. Demonstrate any connection to individual standing. |
| 12–16 | Substantial development of worship, renewed thinking, service, love, public duties, welcome, accountability, mission, cooperation, discernment from God's mercies and Paul's appeals. |

This map does not require renumbering existing movements. Introduce the book without presuming conversion. Romans 9–11 is no longer a concluding historical proof. Romans 12–16 forms the final movement. The conclusion gathers demonstrated claims rather than launching another appeal to feel assured.

## Deal with apparent disagreement

Read warnings with the same care as assurances. Examine judgment according to works (2:6–16), obedience and death (6:15–23), conflict (7:14–25), belonging to Christ and life by the Spirit (8:9–17), standing by faith and being cut off (11:17–23), and accountability (14:10–12, 23).

For each difficulty, explain what it says, whom it addresses, its place in the argument, the reasons for the interpretation, and its implications for the thesis. Do not dismiss it as hypothetical, national, temporal, or irrelevant without demonstration. Do not bury contradictions in questions or editorial notes while asserting certainty in the chapter. If a difficulty remains unresolved, acknowledge it and withhold the stronger claim.

## Inability, faith, and obedience

Specify the inability the passage addresses: works do not justify the sinner; the flesh does not accomplish what God's law requires. Do not expand this to inability to respond to revelation by faith without textual demonstration. Clarify in context instead of adding a declaration of theological allegiance.

Faith, repentance, obedience, and responsibility retain their place in Paul's argument. God-centered writing does not remove commands or ban human pronouns. Distinguish earning acceptance from commanded obedience, and condemnation from recognition of wrong, remorse, consequences, and responsibility to those harmed. Never promise automatic emotional calm, freedom from temptation, or effortless obedience through understanding.

## Voice and study

Use plain, connected English. Remove repetitive announcements, stacked fragments, forced contrasts, abstractions, interchangeable paragraphs, and manufactured climaxes. Let the reasoning carry the force. Preserve truthful testimony without invented experience; testimony is not doctrinal proof.

Questions should invite observation, tracing Paul's reasons, examination of difficulties, and consideration of the obedience he describes. Do not presume conversion, demand agreement, or prescribe an emotional response.

## Review gate

Before delivering, ask: What does this passage contribute? What does God do, and how does the text establish it? Is the conclusion explicit or inferred? Have warnings and qualifications been explained? Has subjective experience displaced the subject? Is inability precisely stated? Are faith and obedience treated in context? Is this repeating another chapter?

The test is whether the reader has been shown the grounds in Romans for **It is settled**, with an honest explanation of apparent challenges—not whether the prose sounds reassuring.
