# Project brief

## Current decisions

- John Wry, **It Is Settled**. Working subtitle: **Our Standing Before God through Christ**; descriptor: **A Guided Reading and Study of Romans**. Follow later author wording.
- Follow all Romans, with a substantial final movement on 12–16. The earlier ban on a tour was superseded by John's later decision.
- `book-framework.md` governs purpose, argument, and review. It supersedes the old testimony-led structure and conclusion about where confidence rests.
- Original manuscript remains source material. Revised drafts and earlier assistant prose require checking, not automatic endorsement.
- Preserve peace with God versus feeling peaceful without making feelings the organizing subject.
- Scripture alone establishes teaching. No outside theological commentary or predetermined theological system.
- **World English Bible (WEB) is selected**, expressly confirmed by John on October 7, 2026. Use the Classic American English edition consistently unless John selects another WEB edition. No new NASB or ASV quotations. Verify existing quotations individually when replacing them; do not merely relabel them.

## Testimony record

John reports thirteen years of missionary service, desire to help people and do something for God, discipline and commitments, and cycles of effort, achievement, pride, failure, and guilt. The manuscript describes spiritual and ministry exhaustion when someone posed the admission question. It also describes sins hidden from people he ministered to. Do not expand their nature or other factual details without asking.

Preserve the intended meaning of:

“Why should I let you in?”

“Because I gave you my life.”

“I thought He gave His life for you.”

Another person posed the first question as a hypothetical question from God. Do not narrate an actual conversation with God. John's answer exposed reliance on his service rather than Christ's saving work. Repair narration and pronouns without supplying memories.

## Edition verification

Checked October 7, 2026 for administrative purposes only:
- ASV (1901): https://ebible.org/asv/FRT01.htm identifies the translation as public domain following copyright expiration.
- WEB: https://worldenglish.bible/ identifies its translation as public domain and permits copying, quotation, printing, and distribution. Its name identifies faithful copies; label paraphrases separately.

Existing quotations have not been converted by this update. Verify each replacement and edition attribution. Do not carry NASB permission limits or notices over to public-domain replacements; remaining third-party material requires its own review.
